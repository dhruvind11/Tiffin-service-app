import React from 'react'

function CardDetails() {
  return (
    <div style={{marginBottom:"18%"}}>
      <h1>dskvnd</h1>
      <h1>dskvnd</h1>
      <h1>dskvnd</h1>

      <h1>dskvnd</h1>

      <h1>dskvnd</h1>

      <h1>dskvnd</h1>

      <h1>dskvnd</h1>
      
    </div>
  )
}

export default CardDetails
