import React from 'react'
import Main from './Main'
function Base() {
  return (
    <div>
        <Main/>
    </div>
  )
}

export default Base