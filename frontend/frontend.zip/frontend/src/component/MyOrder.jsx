import React from 'react'

function MyOrder() {
  return (
    <div className='wrap-1'>
      <h1>my order</h1>
    </div>
  )
}

export default MyOrder
